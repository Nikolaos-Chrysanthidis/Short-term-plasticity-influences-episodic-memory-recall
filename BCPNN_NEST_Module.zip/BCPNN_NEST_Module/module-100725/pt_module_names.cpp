/*
 *  pt_module_names.cpp
 *
 *  2011 Philip Tully
 */


#include "pt_module_names.h"

namespace pT_module
{
  namespace names
  {
    const Name V_th_phil("V_th_phil");       // voltage at W_min
   
  }
}
